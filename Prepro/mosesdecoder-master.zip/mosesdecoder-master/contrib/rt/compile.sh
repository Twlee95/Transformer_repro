gcc -c Empty.c -o Empty.o
ar rcs librt.a Empty.o